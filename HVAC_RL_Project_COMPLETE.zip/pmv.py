"""
pmv.py
Fanger's PMV (Predicted Mean Vote) thermal comfort model.
Reference: Fanger, P. O. (1970). Thermal comfort.
"""

import math


def saturation_vapor_pressure(t_air):
    """Approximate saturation vapor pressure (kPa) at air temp (C)."""
    return 0.6105 * math.exp((17.27 * t_air) / (t_air + 237.3))


def compute_pmv(t_air, t_mrt, rh, v_air=0.1, met=1.2, clo=0.5):
    """
    Compute PMV using Fanger's model (standard ASHRAE 55 / ISO 7730 form).

    t_air : indoor air temperature (C)
    t_mrt : mean radiant temperature (C) - can be approximated as t_air
    rh    : relative humidity (%)
    v_air : air velocity (m/s)
    met   : metabolic rate (met units, 1 met = 58.15 W/m^2)
    clo   : clothing insulation (clo units, 1 clo = 0.155 m^2K/W)
    """
    pa = rh / 100.0 * saturation_vapor_pressure(t_air) * 1000  # Pa
    icl = 0.155 * clo
    m = met * 58.15
    w = 0.0  # external work, assumed 0
    mw = m - w

    fcl = 1 + 1.29 * icl if icl <= 0.078 else 1.05 + 0.645 * icl

    taa = t_air + 273.0
    tra = t_mrt + 273.0

    # iterate for clothing surface temperature (all in the /100 Kelvin form
    # used by the standard Fanger/ASHRAE algorithm)
    tcla = taa + (35.5 - t_air) / (3.5 * icl + 0.1)
    p1 = icl * fcl
    p2 = p1 * 3.96
    p3 = p1 * 100.0
    p4 = p1 * taa
    p5 = 308.7 - 0.028 * mw + p2 * (tra / 100.0) ** 4

    xn = tcla / 100.0
    xf = tcla / 100.0
    n = 0
    eps = 0.00015
    hc = 0.0
    while True:
        xf = (xf + xn) / 2.0
        hcf = 12.1 * math.sqrt(v_air)
        hcn = 2.38 * abs(100 * xf - taa) ** 0.25
        hc = hcf if hcf > hcn else hcn
        xn = (p5 + p4 * hc - p2 * xf ** 4) / (100.0 + p3 * hc)
        n += 1
        if n > 150 or abs(xn - xf) <= eps:
            break

    tcl = 100.0 * xn - 273.0

    # heat loss components (all in W/m^2)
    hl1 = 3.05e-3 * (5733 - 6.99 * mw - pa)
    hl2 = 0.42 * (mw - 58.15) if mw > 58.15 else 0.0
    hl3 = 1.7e-5 * m * (5867 - pa)
    hl4 = 0.0014 * m * (34 - t_air)
    hl5 = 3.96 * fcl * (xn ** 4 - (tra / 100.0) ** 4)
    hl6 = fcl * hc * (tcl - t_air)

    ts = 0.303 * math.exp(-0.036 * m) + 0.028
    pmv = ts * (mw - hl1 - hl2 - hl3 - hl4 - hl5 - hl6)
    return pmv


def compute_ppd(pmv):
    """Predicted Percentage Dissatisfied, derived from PMV."""
    return 100 - 95 * math.exp(-0.03353 * pmv ** 4 - 0.2179 * pmv ** 2)


if __name__ == "__main__":
    pmv = compute_pmv(t_air=26, t_mrt=26, rh=60)
    print(f"PMV = {pmv:.3f}, PPD = {compute_ppd(pmv):.1f}%")
