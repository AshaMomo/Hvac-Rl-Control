"""
train_sac.py
Trains the SAC agent (Person 2's main deliverable) on the
GridResilientHVACEnv, and can toggle grid-context on/off for the
ablation study (RQ4, condition C5 vs C4).

Requires: pip install stable-baselines3 sinergym
"""

import argparse
from stable_baselines3 import SAC
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import EvalCallback

from hvac_env import make_env


def train(env_id, total_timesteps, use_grid_context=True,
          seed=0, log_dir="./logs", save_path="./models/sac_hvac"):
    env = make_env(sinergym_env_id=env_id, seed=seed)
    env = Monitor(env, log_dir)

    # Ablation switch (C5): zero-out the grid-risk term by monkey-patching
    # the reward weight (quick way to disable Pgrid_risk contribution)
    if not use_grid_context:
        import reward as reward_module
        _orig = reward_module.compute_reward

        def no_grid_reward(*args, **kwargs):
            kwargs.setdefault("base_weights", {"w1": 1.0, "w2": 1.0, "w3": 0.5, "w4": 0.0})
            return _orig(*args, **kwargs)

        reward_module.compute_reward = no_grid_reward

    model = SAC(
        "MlpPolicy",
        env,
        learning_rate=3e-4,
        buffer_size=200_000,
        batch_size=256,
        gamma=0.99,
        tau=0.005,
        train_freq=1,
        gradient_steps=1,
        verbose=1,
        seed=seed,
        tensorboard_log=log_dir,
    )

    eval_env = Monitor(make_env(sinergym_env_id=env_id, seed=seed + 1), log_dir)
    eval_cb = EvalCallback(eval_env, best_model_save_path=save_path,
                            log_path=log_dir, eval_freq=5000, deterministic=True)

    model.learn(total_timesteps=total_timesteps, callback=eval_cb)
    model.save(save_path)
    print(f"Saved model to {save_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--env_id", default="Eplus-residential-hot-continuous-v1")
    parser.add_argument("--timesteps", type=int, default=200_000)
    parser.add_argument("--no_grid_context", action="store_true",
                         help="Run the C5 ablation (SAC without grid-context)")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    train(args.env_id, args.timesteps,
          use_grid_context=not args.no_grid_context, seed=args.seed)
