"""
grid_signal.py
Simulates Bangladesh-style unscheduled load-shedding for the grid_status
context signal used in the reward function and context tensor.
"""

import numpy as np


class LoadSheddingSimulator:
    """
    Generates a per-timestep grid outage probability / state signal.
    Two modes:
      - "historical": schedule-based (fixed daily outage windows + noise)
      - "stochastic": Bernoulli outage draws per timestep with a base rate
    """

    def __init__(self, steps_per_day=96, base_outage_rate=0.08,
                 scheduled_windows=None, seed=None):
        self.steps_per_day = steps_per_day
        self.base_outage_rate = base_outage_rate
        # e.g. [(18, 19.5), (13, 13.5)] -> hours (start, end) with higher outage risk
        self.scheduled_windows = scheduled_windows or [(13.0, 13.5), (18.0, 19.5)]
        self.rng = np.random.default_rng(seed)

    def _hour_of_step(self, step):
        step_in_day = step % self.steps_per_day
        return (step_in_day / self.steps_per_day) * 24.0

    def grid_risk(self, step):
        """Return probability [0,1] of outage risk at this step (for context tensor)."""
        hour = self._hour_of_step(step)
        risk = self.base_outage_rate
        for start, end in self.scheduled_windows:
            if start <= hour <= end:
                risk = min(1.0, risk + 0.55)
        return risk

    def sample_outage(self, step):
        """Sample whether an outage is actually happening at this step (0/1)."""
        risk = self.grid_risk(step)
        return int(self.rng.random() < risk)

    def generate_episode(self, n_steps):
        """Return arrays of (risk, outage) for a full episode, for logging/eval."""
        risks = np.array([self.grid_risk(s) for s in range(n_steps)])
        outages = np.array([self.sample_outage(s) for s in range(n_steps)])
        return risks, outages


if __name__ == "__main__":
    sim = LoadSheddingSimulator(seed=42)
    risks, outages = sim.generate_episode(96)
    print("Outage steps today:", outages.sum(), "/", len(outages))
