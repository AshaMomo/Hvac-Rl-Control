"""
context.py
Builds the extended context tensor:
  s_context = [time, occupancy, weather, season, grid_status]
and the context modifier Phi(s_context) used to reweight the reward.
"""

import numpy as np


def build_context_vector(hour, occupancy, outdoor_temp, season_id, grid_risk):
    """
    hour         : 0-23 (float)
    occupancy    : 0 or 1 (house empty / occupied) - can be probability too
    outdoor_temp : current outdoor temperature (C)
    season_id    : 0=winter, 1=summer (extend as needed)
    grid_risk    : 0-1 probability of imminent load-shedding
    """
    hour_norm = hour / 24.0
    temp_norm = np.clip((outdoor_temp - 10) / 30.0, 0, 1)  # rough normalization
    return np.array([hour_norm, occupancy, temp_norm, season_id, grid_risk],
                     dtype=np.float32)


def context_modifier(context_vec, base_weights):
    """
    Phi(s_context): dynamically reshapes reward weights based on context.
    - If occupancy == 0: comfort penalty weight (w2) is heavily reduced.
    - If grid_risk is high: grid-risk weight (w4) increases.
    Returns a new weight dict.
    """
    hour_norm, occupancy, temp_norm, season_id, grid_risk = context_vec
    w = dict(base_weights)  # copy

    if occupancy < 0.5:
        w["w2"] *= 0.2  # comfort matters much less when nobody's home

    if grid_risk > 0.5:
        w["w4"] *= 1.0 + grid_risk  # scale up grid-risk weight when risk is high

    return w


if __name__ == "__main__":
    ctx = build_context_vector(hour=18.5, occupancy=1, outdoor_temp=34, season_id=1, grid_risk=0.7)
    base_w = {"w1": 1.0, "w2": 1.0, "w3": 0.5, "w4": 1.0}
    print("context:", ctx)
    print("adjusted weights:", context_modifier(ctx, base_w))
