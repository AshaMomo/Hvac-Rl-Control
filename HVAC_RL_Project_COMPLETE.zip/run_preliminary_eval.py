"""
run_preliminary_eval.py
Runs a 1-day (96-step, 15-min interval) preliminary comparison between:
  - Rule-Based ON/OFF thermostat (C1)
  - Grid-aware SAC-style controller (proxy: uses reward.py logic to pick
    the best of several candidate actions each step, since a full trained
    SAC model isn't available yet without EnergyPlus/Sinergym)
This produces REAL numbers (computed by pmv.py / reward.py / grid_signal.py)
for the mid-project report's Preliminary Results section - not fabricated,
but a simplified stand-in simulation since the full building simulator
(EnergyPlus) is not yet installed by the team.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from pmv import compute_pmv
from grid_signal import LoadSheddingSimulator
from context import build_context_vector
from reward import compute_reward
from baselines import RuleBasedThermostat

np.random.seed(0)
STEPS = 96  # 24 hours, 15-min steps

# --- Real-world-grounded Dhaka weather profile ---
# Loaded from dhaka_weather_data.csv: an hourly representative-day profile
# for Dhaka's hot/humid pre-monsoon season (Apr-May), built from published
# Bangladesh Meteorological Department (BMD) climate normals. This is a
# representative-day approximation, NOT a raw EnergyPlus .epw weather file
# (that requires the full EnergyPlus/Sinergym building simulator - see
# README "Data & Simulation Status" section). It replaces the earlier
# rough sine-wave placeholder with numbers grounded in real Dhaka climate.
_weather_df = pd.read_csv("dhaka_weather_data.csv")
hours = np.arange(STEPS) / 4.0
# interpolate the 24 hourly readings up to 96 15-min steps
outdoor_temp = np.interp(hours % 24, _weather_df["hour"], _weather_df["outdoor_temp_c"])
outdoor_temp = outdoor_temp + np.random.normal(0, 0.15, STEPS)  # small sensor-noise jitter
humidity = np.interp(hours % 24, _weather_df["hour"], _weather_df["humidity_pct"])

grid_sim = LoadSheddingSimulator(steps_per_day=STEPS, seed=1)
risks, outages = grid_sim.generate_episode(STEPS)

# --- Rule-based (C1) simulation ---
rb = RuleBasedThermostat(setpoint=25.0, deadband=1.0)
t_air_rb = 27.0
rb_log = []
prev_action_rb = 0.0
for t in range(STEPS):
    action = rb.act(t_air_rb)
    # simple thermal response: AC ON cools room toward setpoint, else drifts to outdoor temp
    if action == 1.0 and not outages[t]:
        t_air_rb += 0.35 * (18 - t_air_rb)
    else:
        t_air_rb += 0.15 * (outdoor_temp[t] - t_air_rb)
    energy = 0.6 if (action == 1.0 and not outages[t]) else 0.0
    pmv = compute_pmv(t_air_rb, t_air_rb, humidity[t])
    switch = abs(action - prev_action_rb)
    prev_action_rb = action
    rb_log.append({"t": t, "t_air": t_air_rb, "pmv": pmv, "energy": energy,
                    "switch": switch, "outage": outages[t]})

df_rb = pd.DataFrame(rb_log)

# --- Grid-aware reward-guided controller (proxy for SAC) ---
candidate_actions = np.linspace(0, 1, 6)  # 0=off .. 1=full cooling
t_air_sac = 27.0
prev_action_sac = 0.0
sac_log = []
for t in range(STEPS):
    hour = hours[t] % 24
    occupancy = 1
    season_id = 1
    ctx = build_context_vector(hour, occupancy, outdoor_temp[t], season_id, risks[t])

    best_a, best_r = 0.0, -1e9
    for a in candidate_actions:
        # simulate one-step-ahead effect of this candidate action
        if outages[t]:
            eff_a = 0.0  # can't run AC during actual outage
        else:
            eff_a = a
        t_next = t_air_sac + 0.35 * eff_a * (18 - t_air_sac) + 0.15 * (1 - eff_a) * (outdoor_temp[t] - t_air_sac)
        energy = 0.6 * eff_a
        r, comp = compute_reward(energy_kwh=energy, t_air=t_next, t_mrt=t_next, rh=humidity[t],
                                  action_t=a, action_t_minus_1=prev_action_sac,
                                  context_vec=ctx,
                                  is_precooling_or_preheating=(risks[t] > 0.5 and a > 0.5),
                                  comfort_ok=abs(compute_pmv(t_next, t_next, humidity[t])) < 0.5)
        if r > best_r:
            best_r, best_a, best_t_next, best_energy, best_comp = r, a, t_next, energy, comp

    t_air_sac = best_t_next
    switch = abs(best_a - prev_action_sac)
    prev_action_sac = best_a
    sac_log.append({"t": t, "t_air": t_air_sac, "pmv": best_comp["pmv"], "energy": best_energy,
                     "switch": switch, "outage": outages[t]})

df_sac = pd.DataFrame(sac_log)

# --- Summary table ---
summary = pd.DataFrame({
    "Controller": ["Rule-Based (C1)", "Grid-Aware Reward-Guided (proxy for SAC)"],
    "Total Energy (kWh)": [df_rb["energy"].sum(), df_sac["energy"].sum()],
    "Mean |PMV|": [df_rb["pmv"].abs().mean(), df_sac["pmv"].abs().mean()],
    "Switching Count": [(df_rb["switch"] > 0.05).sum(), (df_sac["switch"] > 0.05).sum()],
    "Comfort Violations (|PMV|>0.5)": [(df_rb["pmv"].abs() > 0.5).sum(), (df_sac["pmv"].abs() > 0.5).sum()],
})
print(summary.to_string(index=False))
summary.to_csv("preliminary_results.csv", index=False)

# --- Plot ---
fig, axes = plt.subplots(2, 1, figsize=(9, 7), sharex=True)
axes[0].plot(hours, df_rb["t_air"], label="Rule-Based indoor temp")
axes[0].plot(hours, df_sac["t_air"], label="Grid-Aware indoor temp")
axes[0].plot(hours, outdoor_temp, "--", color="gray", alpha=0.6, label="Outdoor temp")
for t in range(STEPS):
    if outages[t]:
        axes[0].axvspan(hours[t], hours[t] + 0.25, color="red", alpha=0.08)
axes[0].set_ylabel("Temperature (C)")
axes[0].legend(loc="upper right", fontsize=8)
axes[0].set_title("Indoor Temperature over 24h (red = grid outage)")

axes[1].plot(hours, df_rb["pmv"], label="Rule-Based PMV")
axes[1].plot(hours, df_sac["pmv"], label="Grid-Aware PMV")
axes[1].axhline(0.5, color="orange", linestyle=":", linewidth=1)
axes[1].axhline(-0.5, color="orange", linestyle=":", linewidth=1)
axes[1].set_ylabel("PMV")
axes[1].set_xlabel("Hour of day")
axes[1].legend(loc="upper right", fontsize=8)
axes[1].set_title("Thermal Comfort (PMV) over 24h")

plt.tight_layout()
plt.savefig("preliminary_results.png", dpi=140)
print("\nSaved: preliminary_results.csv, preliminary_results.png")
