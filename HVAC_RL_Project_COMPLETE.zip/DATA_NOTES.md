# Data & Simulation Status — plain-language notes

## Keno age "value" gulo kom/fake mone hoise?

`run_preliminary_eval.py` EnergyPlus/Sinergym (real building simulator) use
kore na — eta beshi heavy software, install korte time lage ebong exam/demo
te chalano kothin. Tai script-ta ekta **simplified stand-in physics model**
use kortesilo (ekta rough sine-wave outdoor temperature diye) — eta bollei
bujha jay je number gulo "generic" lagtesilo, karon eta kono real Dhaka
weather data theke asheni.

## Ki change korlam

- `dhaka_weather_data.csv` — ekta notun file. Eta Dhaka'r hot/humid season
  (April-May) er **published BMD (Bangladesh Meteorological Department)
  climate normals** er upor base kore banano — ekta representative din er
  hour-by-hour temperature (~27°C rate e min, ~35°C max) ebong humidity
  (~50-85%). Eta **public, kono private/paid data na**.
- `run_preliminary_eval.py` ekhon eই CSV theke temperature/humidity read
  kore, age'r random sine-wave er bodole.
- PMV comfort calculation ekhon real humidity value use kortese (age fixed
  60% hardcoded silo).

## Eta ki EnergyPlus .epw file er shomoshoman?

**Na.** Eta ekta "representative day" approximation — full EnergyPlus .epw
weather file na (jeta 8760 hours/year, real station-measured data thake).
Full accuracy lagle final report e clearly likhte hobe:

> "Preliminary results use a representative-day climate profile derived
> from published BMD climate normals, as a stand-in for full EnergyPlus/
> Sinergym building simulation with a Dhaka .epw file, which requires
> EnergyPlus installation not yet completed by the team."

Eta shotti kotha, ebong journal/conference report e ei ধরনের honest
limitation-statement completely normal — evaluator eta dekhle problem hobe
na, ulta na bolle beshi problem hobe.

## Full accuracy chaile next step ki (optional, final report er jonno)

1. EnergyPlus install koro: https://energyplus.net/downloads
2. Dhaka'r `.epw` weather file download koro (public, free):
   https://climate.onebuilding.org (BGD region e Dhaka file ache)
3. `sinergym`-e ei `.epw` file diye ekta building config banao, `hvac_env.py`
   te `sinergym_env_id` set koro.
4. Tarpor `train_sac.py` diye actual SAC training chalate parba (200k+
   timesteps lagte pare, GPU/onek time lagbe — tai eta thesis-level e kora
   hoy, mid-project stage e na).

## User hishebe ami ki dibo, ki dekhbo? (simple version)

- **Tumi ki dao:** kichu direct dite hoy na — shob dataset/config already
  code-e ache (`dhaka_weather_data.csv`, `grid_signal.py`'r load-shedding
  pattern). Just `python run_preliminary_eval.py` run korle hoy.
- **Tumi ki dekho (output):** duita jinis toiri hoy —
  - `preliminary_results.csv` — table: total energy (kWh), average comfort
    error (PMV), koto bar AC switch hoise, koto bar comfort violate hoise —
    Rule-Based vs Grid-Aware controller compare kore.
  - `preliminary_results.png` — graph: 24 ghonta dhore indoor temperature o
    PMV, red shaded area gulo load-shedding er somoy dekhay.
- Report e eই table/graph-ta "Preliminary Results" section e boshiye dile
  hobe, sathe upore deya honest limitation-statement ta likhe dile.
