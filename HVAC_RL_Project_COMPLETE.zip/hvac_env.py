"""
hvac_env.py
Gymnasium-compatible wrapper around Sinergym for the grid-resilient
residential HVAC controller.

NOTE: requires `pip install sinergym` and EnergyPlus installed.
This wraps a base Sinergym env and injects the extended context signal
(occupancy disturbance + grid load-shedding) plus the custom reward.
"""

import os
import gymnasium as gym
import numpy as np

from context import build_context_vector
from grid_signal import LoadSheddingSimulator
from reward import compute_reward

# Dhaka weather file (TMYx 2011-2025, downloaded from climate.onebuilding.org)
# used to configure the Sinergym/EnergyPlus building simulation for Bangladesh.
DHAKA_WEATHER_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "weather",
    "BGD_DH_Dhaka-Shahjalal.Intl.AP.419220_TMYx.2011-2025.epw",
)


class GridResilientHVACEnv(gym.Wrapper):
    """
    Wraps a Sinergym single-family residential env, e.g.:
        import sinergym
        base_env = gym.make("Eplus-residential-hot-continuous-v1")
    Replace the id above with the actual Dhaka-configured building/weather env.
    """

    def __init__(self, base_env, steps_per_day=96, seed=None):
        super().__init__(base_env)
        self.grid_sim = LoadSheddingSimulator(steps_per_day=steps_per_day, seed=seed)
        self.step_count = 0
        self.prev_action = 0.0

        # extend observation space by 1 dim for grid_risk (adjust to your obs space)
        low = np.append(self.observation_space.low, 0.0)
        high = np.append(self.observation_space.high, 1.0)
        self.observation_space = gym.spaces.Box(low=low, high=high,
                                                  dtype=np.float32)

    def _augment_obs(self, obs, info):
        grid_risk = self.grid_sim.grid_risk(self.step_count)
        return np.append(obs, grid_risk).astype(np.float32), grid_risk

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.step_count = 0
        self.prev_action = 0.0
        obs, grid_risk = self._augment_obs(obs, info)
        info["grid_risk"] = grid_risk
        return obs, info

    def step(self, action):
        obs, base_reward, terminated, truncated, info = self.env.step(action)
        self.step_count += 1

        obs, grid_risk = self._augment_obs(obs, info)

        # pull required signals out of `info` - field names depend on your
        # Sinergym variable config, adjust as needed
        t_air = info.get("air_temperature", 26.0)
        rh = info.get("air_humidity", 60.0)
        energy_kwh = info.get("total_electricity_HVAC", 0.0)
        hour = info.get("hour", (self.step_count % 96) / 96 * 24)
        occupancy = info.get("occupancy", 1)
        season_id = info.get("season_id", 0)

        act_scalar = float(np.mean(action)) if hasattr(action, "__len__") else float(action)

        ctx = build_context_vector(hour, occupancy, t_air, season_id, grid_risk)
        reward, components = compute_reward(
            energy_kwh=energy_kwh, t_air=t_air, t_mrt=t_air, rh=rh,
            action_t=act_scalar, action_t_minus_1=self.prev_action,
            context_vec=ctx,
        )
        self.prev_action = act_scalar

        info["reward_components"] = components
        info["grid_risk"] = grid_risk
        return obs, reward, terminated, truncated, info


def make_env(sinergym_env_id="Eplus-residential-hot-continuous-v1", seed=None):
    import sinergym  # noqa: F401  (registers Eplus- envs)
    # NOTE: the `weather_file` kwarg name can vary slightly between Sinergym
    # versions (some use `weather_files=[...]` or a config dict instead).
    # If gym.make() errors on this kwarg, check `pip show sinergym` version
    # and see DATA_NOTES.md for the alternative config-file approach.
    base_env = gym.make(sinergym_env_id, weather_file=DHAKA_WEATHER_FILE)
    return GridResilientHVACEnv(base_env, seed=seed)


if __name__ == "__main__":
    env = make_env()
    obs, info = env.reset()
    print("obs shape:", obs.shape)
