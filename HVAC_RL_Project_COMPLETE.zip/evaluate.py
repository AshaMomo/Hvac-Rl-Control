"""
evaluate.py
Runs a trained agent (or baseline) over test episodes and reports the
metrics used in the report (Section 4.2 / Table results):
  - Energy Consumption (kWh)
  - PMV deviation
  - Switching Frequency
  - Comfort Violation Duration
  - Cumulative Reward
"""

import numpy as np
import pandas as pd

from hvac_env import make_env


def evaluate_agent(model, env_id, n_episodes=5, seed=0, comfort_pmv_bound=0.5):
    env = make_env(sinergym_env_id=env_id, seed=seed)
    results = []

    for ep in range(n_episodes):
        obs, info = env.reset()
        done = False
        ep_energy, ep_reward, switch_count = 0.0, 0.0, 0
        comfort_violation_steps = 0
        prev_action = None
        step_count = 0

        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated

            comp = info.get("reward_components", {})
            ep_energy += comp.get("energy", 0.0)
            ep_reward += reward
            step_count += 1

            if prev_action is not None and abs(float(np.mean(action)) - prev_action) > 0.05:
                switch_count += 1
            prev_action = float(np.mean(action))

            if abs(comp.get("pmv", 0.0)) > comfort_pmv_bound:
                comfort_violation_steps += 1

        results.append({
            "episode": ep,
            "energy_kwh": ep_energy,
            "cumulative_reward": ep_reward,
            "switching_frequency": switch_count,
            "comfort_violation_steps": comfort_violation_steps,
            "steps": step_count,
        })

    return pd.DataFrame(results)


if __name__ == "__main__":
    from stable_baselines3 import SAC

    model = SAC.load("./models/sac_hvac")
    df = evaluate_agent(model, env_id="Eplus-residential-hot-continuous-v1")
    print(df)
    print("\nMeans:\n", df.mean(numeric_only=True))
    df.to_csv("./results/sac_eval.csv", index=False)
