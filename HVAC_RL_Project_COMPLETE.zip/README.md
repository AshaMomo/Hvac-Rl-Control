# Grid-Resilient SAC HVAC Controller — Code

Code for the CSE407 term project:
"A Reinforcement Learning Framework for Energy-Efficient and Grid-Resilient
Residential HVAC Control"

## Files
- `pmv.py` — Fanger's PMV thermal comfort calculation (used by reward.py)
- `grid_signal.py` — simulates Bangladesh-style load-shedding (grid_status signal)
- `context.py` — builds the context tensor + context modifier Phi(s_context)
- `reward.py` — full reward function R_t (energy + PMV + switching + grid-risk)
- `hvac_env.py` — Gymnasium wrapper around Sinergym injecting context + reward
- `train_sac.py` — trains the SAC agent; `--no_grid_context` runs the C5 ablation
- `baselines.py` — C1 Rule-Based, C2 DQN, C3 simplified MPC
- `evaluate.py` — runs a trained model and reports the evaluation metrics

## Setup
```bash
pip install -r requirements.txt
# EnergyPlus must be installed separately for Sinergym to work:
# https://energyplus.net/downloads
```

Set `sinergym_env_id` in `hvac_env.py` / `train_sac.py` to whichever
Sinergym environment is configured with the Dhaka .epw weather file.

## Usage
```bash
# Train the full SAC agent (C4)
python train_sac.py --timesteps 200000

# Train the ablation without grid-context (C5)
python train_sac.py --timesteps 200000 --no_grid_context

# Train DQN baseline (C2)
python -c "from baselines import train_dqn_baseline; train_dqn_baseline('Eplus-residential-hot-continuous-v1')"

# Evaluate a trained model
python evaluate.py
```

## Notes
- `hvac_env.py` reads fields like `air_temperature`, `air_humidity`,
  `total_electricity_HVAC`, `hour`, `occupancy`, `season_id` from Sinergym's
  `info` dict — rename these to match your actual Sinergym variable
  configuration once the building model is set up.
- `SimpleMPC` in `baselines.py` is a lightweight one-step-lookahead
  benchmark, not a full optimization-based MPC — swap in `cvxpy` if a
  stronger MPC baseline is needed.
