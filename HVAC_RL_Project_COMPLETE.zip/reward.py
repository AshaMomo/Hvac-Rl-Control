"""
reward.py
Implements the reward function:

  R_t = - [ w1 * P_energy(t) + w2 * |PMV(t)| + w3 * delta_f_switch(t)
            + w4 * P_grid_risk(t) ] * Phi(s_context)

as defined in the proposal (Section 5.C).
"""

from pmv import compute_pmv
from context import context_modifier


def switching_penalty(action_t, action_t_minus_1):
    """delta_f_switch(t) = |a_t - a_t-1|"""
    return abs(action_t - action_t_minus_1)


def grid_risk_penalty(is_precooling_or_preheating, grid_risk, comfort_ok):
    """
    P_grid_risk(t): penalizes NOT pre-conditioning ahead of high outage risk,
    rewards proactive pre-cooling/pre-heating that keeps comfort_ok=True
    during an outage.
    """
    if grid_risk > 0.5 and not is_precooling_or_preheating:
        return grid_risk  # penalty for being unprepared
    if grid_risk > 0.5 and is_precooling_or_preheating and comfort_ok:
        return -0.2 * grid_risk  # small bonus (negative penalty) for good prep
    return 0.0


def compute_reward(energy_kwh, t_air, t_mrt, rh, action_t, action_t_minus_1,
                    context_vec, is_precooling_or_preheating=False,
                    comfort_ok=True, base_weights=None):
    """
    Returns (reward, components_dict) so components can be logged separately
    for the ablation studies (RQ2, RQ4).
    """
    if base_weights is None:
        base_weights = {"w1": 1.0, "w2": 1.0, "w3": 0.5, "w4": 1.0}

    w = context_modifier(context_vec, base_weights)

    p_energy = energy_kwh
    pmv = compute_pmv(t_air, t_mrt, rh)
    d_switch = switching_penalty(action_t, action_t_minus_1)
    p_grid = grid_risk_penalty(is_precooling_or_preheating,
                                grid_risk=context_vec[4],
                                comfort_ok=comfort_ok)

    penalty = (w["w1"] * p_energy + w["w2"] * abs(pmv)
               + w["w3"] * d_switch + w["w4"] * p_grid)

    reward = -penalty

    components = {
        "reward": reward, "pmv": pmv, "energy": p_energy,
        "switching": d_switch, "grid_risk_term": p_grid, "weights": w,
    }
    return reward, components


if __name__ == "__main__":
    from context import build_context_vector
    ctx = build_context_vector(hour=18.5, occupancy=1, outdoor_temp=34, season_id=1, grid_risk=0.7)
    r, comp = compute_reward(energy_kwh=1.2, t_air=27, t_mrt=27, rh=65,
                              action_t=0.6, action_t_minus_1=0.3, context_vec=ctx)
    print(r, comp)
