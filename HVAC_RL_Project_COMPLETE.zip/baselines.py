"""
baselines.py
Baseline controllers (C1-C3) for comparison against SAC:
  C1: Rule-Based ON/OFF thermostat
  C2: Discrete DQN
  C3: simplified Model Predictive Control (MPC)
"""

import numpy as np


class RuleBasedThermostat:
    """C1: classic ON/OFF band controller."""

    def __init__(self, setpoint=24.0, deadband=1.0):
        self.setpoint = setpoint
        self.deadband = deadband
        self.state = 0  # 0 = off, 1 = on

    def act(self, t_air):
        if t_air > self.setpoint + self.deadband:
            self.state = 1
        elif t_air < self.setpoint - self.deadband:
            self.state = 0
        return float(self.state)


def train_dqn_baseline(env_id, total_timesteps=200_000, seed=0):
    """C2: Discrete DQN baseline, using stable-baselines3."""
    from stable_baselines3 import DQN
    from hvac_env import make_env

    env = make_env(sinergym_env_id=env_id, seed=seed)
    model = DQN("MlpPolicy", env, learning_rate=1e-4, buffer_size=200_000,
                batch_size=128, gamma=0.99, verbose=1, seed=seed)
    model.learn(total_timesteps=total_timesteps)
    model.save("./models/dqn_baseline")
    return model


class SimpleMPC:
    """
    C3: simplified one-step-lookahead MPC baseline.
    Picks the action (from a discretized action set) that minimizes a
    one-step-ahead cost estimate using a linear thermal model:
        T_next = T_air + k1*(setpoint_action - T_air) + k2*(T_outdoor - T_air)
    This is intentionally simple - a full MPC would use a proper building
    model + optimizer (e.g. CVXPY), but this gives a reasonable benchmark.
    """

    def __init__(self, action_set=None, setpoint=24.0, k1=0.3, k2=0.05):
        self.action_set = action_set or np.linspace(18, 28, 11)
        self.setpoint = setpoint
        self.k1 = k1
        self.k2 = k2

    def act(self, t_air, t_outdoor):
        best_action, best_cost = None, float("inf")
        for a in self.action_set:
            t_next = t_air + self.k1 * (a - t_air) + self.k2 * (t_outdoor - t_air)
            cost = abs(t_next - self.setpoint) + 0.01 * abs(a - t_air)
            if cost < best_cost:
                best_cost, best_action = cost, a
        return best_action


if __name__ == "__main__":
    rb = RuleBasedThermostat()
    print("Rule-based action at 27C:", rb.act(27))

    mpc = SimpleMPC()
    print("MPC action:", mpc.act(t_air=27, t_outdoor=34))
